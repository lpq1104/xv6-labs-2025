#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"
#include "fs.h"
#include "sleeplock.h"
#include "file.h"
#include "net.h"

// xv6's ethernet and IP addresses
static uint8 local_mac[ETHADDR_LEN] = { 0x52, 0x54, 0x00, 0x12, 0x34, 0x56 };
static uint32 local_ip = MAKE_IP_ADDR(10, 0, 2, 15);

// qemu host's ethernet address.
static uint8 host_mac[ETHADDR_LEN] = { 0x52, 0x55, 0x0a, 0x00, 0x02, 0x02 };

static struct spinlock netlock;

// A bound UDP port can hold at most 16 waiting packets.
#define UDP_QUEUE_SIZE 16

// The tests only use a small number of ports.
// NPROC gives us enough independent port slots.
#define MAX_UDP_PORTS NPROC

struct udp_packet {
  uint32 src_ip;       // host byte order
  uint16 src_port;     // host byte order
  char *payload;       // points inside page
  int payload_len;
  char *page;          // original kalloc page, freed after recv
};

struct udp_port {
  int used;
  uint16 port;

  int read_index;
  int write_index;
  int count;

  struct spinlock lock;
  struct udp_packet packets[UDP_QUEUE_SIZE];
};

static struct spinlock udp_table_lock;
static struct udp_port udp_ports[MAX_UDP_PORTS];

void
netinit(void)
{
  initlock(&netlock, "netlock");
  initlock(&udp_table_lock, "udp_table");

  for(int i = 0; i < MAX_UDP_PORTS; i++){
    udp_ports[i].used = 0;
    udp_ports[i].port = 0;
    udp_ports[i].read_index = 0;
    udp_ports[i].write_index = 0;
    udp_ports[i].count = 0;
    initlock(&udp_ports[i].lock, "udp_port");
  }
}

static struct udp_port *
find_udp_port(uint16 port)
{
  struct udp_port *result = 0;

  acquire(&udp_table_lock);

  for(int i = 0; i < MAX_UDP_PORTS; i++){
    if(udp_ports[i].used && udp_ports[i].port == port){
      result = &udp_ports[i];
      break;
    }
  }

  release(&udp_table_lock);
  return result;
}
//
// bind(int port)
// prepare to receive UDP packets address to the port,
// i.e. allocate any queues &c needed.
//
uint64
sys_bind(void)
{
  int port_arg;
  argint(0, &port_arg);

  uint16 port = (uint16)port_arg;

  acquire(&udp_table_lock);

  // The same port cannot be bound twice.
  for(int i = 0; i < MAX_UDP_PORTS; i++){
    if(udp_ports[i].used && udp_ports[i].port == port){
      release(&udp_table_lock);
      return -1;
    }
  }

  // Find an unused port slot.
  for(int i = 0; i < MAX_UDP_PORTS; i++){
    if(udp_ports[i].used == 0){
      struct udp_port *q = &udp_ports[i];

      acquire(&q->lock);

      q->port = port;
      q->read_index = 0;
      q->write_index = 0;
      q->count = 0;

      for(int j = 0; j < UDP_QUEUE_SIZE; j++){
        q->packets[j].src_ip = 0;
        q->packets[j].src_port = 0;
        q->packets[j].payload = 0;
        q->packets[j].payload_len = 0;
        q->packets[j].page = 0;
      }

      // Publish this slot only after it is fully initialized.
      q->used = 1;

      release(&q->lock);
      release(&udp_table_lock);
      return 0;
    }
  }

  release(&udp_table_lock);
  return -1;
}

//
// unbind(int port)
// release any resources previously created by bind(port);
// from now on UDP packets addressed to port should be dropped.
//
uint64
sys_unbind(void)
{
  //
  // Optional: Your code here.
  //

  return 0;
}

//
// recv(int dport, int *src, short *sport, char *buf, int maxlen)
// if there's a received UDP packet already queued that was
// addressed to dport, then return it.
// otherwise wait for such a packet.
//
// sets *src to the IP source address.
// sets *sport to the UDP source port.
// copies up to maxlen bytes of UDP payload to buf.
// returns the number of bytes copied,
// and -1 if there was an error.
//
// dport, *src, and *sport are host byte order.
// bind(dport) must previously have been called.
//
uint64
sys_recv(void)
{
  int port_arg;
  int maxlen;

  uint64 user_src_ip;
  uint64 user_src_port;
  uint64 user_buf;

  argint(0, &port_arg);
  argaddr(1, &user_src_ip);
  argaddr(2, &user_src_port);
  argaddr(3, &user_buf);
  argint(4, &maxlen);

  if(maxlen < 0)
    return -1;

  uint16 port = (uint16)port_arg;
  struct udp_port *q = find_udp_port(port);

  // recv() may only be used after bind().
  if(q == 0)
    return -1;

  acquire(&q->lock);

  // Wait until a packet for this port arrives.
  while(q->count == 0){
    sleep(q, &q->lock);
  }

  int index = q->read_index;
  struct udp_packet *packet = &q->packets[index];

  int copy_len = packet->payload_len;
  if(copy_len > maxlen)
    copy_len = maxlen;

  struct proc *p = myproc();
  int failed = 0;

  if(copyout(p->pagetable,
             user_src_ip,
             (char *)&packet->src_ip,
             sizeof(packet->src_ip)) < 0){
    failed = 1;
  }

  if(copyout(p->pagetable,
             user_src_port,
             (char *)&packet->src_port,
             sizeof(packet->src_port)) < 0){
    failed = 1;
  }

  if(copy_len > 0 &&
     copyout(p->pagetable,
             user_buf,
             packet->payload,
             copy_len) < 0){
    failed = 1;
  }

  // Save the allocation address before clearing the queue entry.
  char *page = packet->page;

  packet->src_ip = 0;
  packet->src_port = 0;
  packet->payload = 0;
  packet->payload_len = 0;
  packet->page = 0;

  q->read_index = (q->read_index + 1) % UDP_QUEUE_SIZE;
  q->count--;

  release(&q->lock);

  // The packet is removed from the queue after recv().
  kfree(page);

  if(failed)
    return -1;

  return copy_len;
}

// This code is lifted from FreeBSD's ping.c, and is copyright by the Regents
// of the University of California.
static unsigned short
in_cksum(const unsigned char *addr, int len)
{
  int nleft = len;
  const unsigned short *w = (const unsigned short *)addr;
  unsigned int sum = 0;
  unsigned short answer = 0;

  /*
   * Our algorithm is simple, using a 32 bit accumulator (sum), we add
   * sequential 16 bit words to it, and at the end, fold back all the
   * carry bits from the top 16 bits into the lower 16 bits.
   */
  while (nleft > 1)  {
    sum += *w++;
    nleft -= 2;
  }

  /* mop up an odd byte, if necessary */
  if (nleft == 1) {
    *(unsigned char *)(&answer) = *(const unsigned char *)w;
    sum += answer;
  }

  /* add back carry outs from top 16 bits to low 16 bits */
  sum = (sum & 0xffff) + (sum >> 16);
  sum += (sum >> 16);
  /* guaranteed now that the lower 16 bits of sum are correct */

  answer = ~sum; /* truncate to 16 bits */
  return answer;
}

//
// send(int sport, int dst, int dport, char *buf, int len)
//
uint64
sys_send(void)
{
  struct proc *p = myproc();
  int sport;
  int dst;
  int dport;
  uint64 bufaddr;
  int len;

  argint(0, &sport);
  argint(1, &dst);
  argint(2, &dport);
  argaddr(3, &bufaddr);
  argint(4, &len);

  int total = len + sizeof(struct eth) + sizeof(struct ip) + sizeof(struct udp);
  if(total > PGSIZE)
    return -1;

  char *buf = kalloc();
  if(buf == 0){
    printf("sys_send: kalloc failed\n");
    return -1;
  }
  memset(buf, 0, PGSIZE);

  struct eth *eth = (struct eth *) buf;
  memmove(eth->dhost, host_mac, ETHADDR_LEN);
  memmove(eth->shost, local_mac, ETHADDR_LEN);
  eth->type = htons(ETHTYPE_IP);

  struct ip *ip = (struct ip *)(eth + 1);
  ip->ip_vhl = 0x45; // version 4, header length 4*5
  ip->ip_tos = 0;
  ip->ip_len = htons(sizeof(struct ip) + sizeof(struct udp) + len);
  ip->ip_id = 0;
  ip->ip_off = 0;
  ip->ip_ttl = 100;
  ip->ip_p = IPPROTO_UDP;
  ip->ip_src = htonl(local_ip);
  ip->ip_dst = htonl(dst);
  ip->ip_sum = in_cksum((unsigned char *)ip, sizeof(*ip));

  struct udp *udp = (struct udp *)(ip + 1);
  udp->sport = htons(sport);
  udp->dport = htons(dport);
  udp->ulen = htons(len + sizeof(struct udp));

  char *payload = (char *)(udp + 1);
  if(copyin(p->pagetable, payload, bufaddr, len) < 0){
    kfree(buf);
    printf("send: copyin failed\n");
    return -1;
  }

  e1000_transmit(buf, total);

  return 0;
}

static void
udp_rx(char *buf, int len)
{
  int header_len =
    sizeof(struct eth) +
    sizeof(struct ip) +
    sizeof(struct udp);

  // Packet is too short to contain Ethernet + IP + UDP.
  if(len < header_len){
    kfree(buf);
    return;
  }

  struct eth *eth = (struct eth *)buf;
  struct ip *ip = (struct ip *)(eth + 1);
  struct udp *udp = (struct udp *)(ip + 1);

  uint16 udp_len = ntohs(udp->ulen);

  // UDP length includes the UDP header.
  if(udp_len < sizeof(struct udp)){
    kfree(buf);
    return;
  }

  // Do not allow the UDP length to extend past the received frame.
  if((int)(sizeof(struct eth) + sizeof(struct ip) + udp_len) > len){
    kfree(buf);
    return;
  }

  uint16 destination_port = ntohs(udp->dport);
  uint16 source_port = ntohs(udp->sport);
  uint32 source_ip = ntohl(ip->ip_src);
  int payload_len = udp_len - sizeof(struct udp);

  struct udp_port *q = find_udp_port(destination_port);

  // Packets for unbound ports must be discarded.
  if(q == 0){
    kfree(buf);
    return;
  }

  acquire(&q->lock);

  // Each port may retain at most 16 waiting packets.
  if(q->count == UDP_QUEUE_SIZE){
    release(&q->lock);
    kfree(buf);
    return;
  }

  int index = q->write_index;
  struct udp_packet *packet = &q->packets[index];

  packet->src_ip = source_ip;
  packet->src_port = source_port;
  packet->payload = (char *)(udp + 1);
  packet->payload_len = payload_len;
  packet->page = buf;

  q->write_index = (q->write_index + 1) % UDP_QUEUE_SIZE;
  q->count++;

  // Wake recv() processes sleeping on this port queue.
  wakeup(q);

  release(&q->lock);
}

void
ip_rx(char *buf, int len)
{
  // Don't delete this printf; make grade depends on it.
  static int seen_ip = 0;
  if(seen_ip == 0)
    printf("ip_rx: received an IP packet\n");
  seen_ip = 1;

  int minimum_ip_len =
    sizeof(struct eth) +
    sizeof(struct ip);

  if(len < minimum_ip_len){
    kfree(buf);
    return;
  }

  struct eth *eth = (struct eth *)buf;
  struct ip *ip = (struct ip *)(eth + 1);

  if(ip->ip_p == IPPROTO_UDP){
    udp_rx(buf, len);
    return;
  }

  // This lab only handles UDP. Other IP packets are discarded.
  kfree(buf);
}

//
// send an ARP reply packet to tell qemu to map
// xv6's ip address to its ethernet address.
// this is the bare minimum needed to persuade
// qemu to send IP packets to xv6; the real ARP
// protocol is more complex.
//
void
arp_rx(char *inbuf)
{
  static int seen_arp = 0;

  if(seen_arp){
    kfree(inbuf);
    return;
  }
  printf("arp_rx: received an ARP packet\n");
  seen_arp = 1;

  struct eth *ineth = (struct eth *) inbuf;
  struct arp *inarp = (struct arp *) (ineth + 1);

  char *buf = kalloc();
  if(buf == 0)
    panic("send_arp_reply");
  
  struct eth *eth = (struct eth *) buf;
  memmove(eth->dhost, ineth->shost, ETHADDR_LEN); // ethernet destination = query source
  memmove(eth->shost, local_mac, ETHADDR_LEN); // ethernet source = xv6's ethernet address
  eth->type = htons(ETHTYPE_ARP);

  struct arp *arp = (struct arp *)(eth + 1);
  arp->hrd = htons(ARP_HRD_ETHER);
  arp->pro = htons(ETHTYPE_IP);
  arp->hln = ETHADDR_LEN;
  arp->pln = sizeof(uint32);
  arp->op = htons(ARP_OP_REPLY);

  memmove(arp->sha, local_mac, ETHADDR_LEN);
  arp->sip = htonl(local_ip);
  memmove(arp->tha, ineth->shost, ETHADDR_LEN);
  arp->tip = inarp->sip;

  e1000_transmit(buf, sizeof(*eth) + sizeof(*arp));

  kfree(inbuf);
}

void
net_rx(char *buf, int len)
{
  struct eth *eth = (struct eth *) buf;

  if(len >= sizeof(struct eth) + sizeof(struct arp) &&
     ntohs(eth->type) == ETHTYPE_ARP){
    arp_rx(buf);
  } else if(len >= sizeof(struct eth) + sizeof(struct ip) &&
     ntohs(eth->type) == ETHTYPE_IP){
    ip_rx(buf, len);
  } else {
    kfree(buf);
  }
}
