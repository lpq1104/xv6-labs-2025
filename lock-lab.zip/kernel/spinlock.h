// Mutual exclusion lock.
struct spinlock {
  uint locked;       // Is the lock held?

  // For debugging:
  char *name;        // Name of lock.
  struct cpu *cpu;   // The cpu holding the lock.
#ifdef LAB_LOCK
  int nts;
  int n;
#endif
};

#ifdef LAB_LOCK
// Reader-writer lock.
struct rwspinlock {
  // Protects all fields below.
  struct spinlock guard;

  // Number of readers currently holding the lock.
  int readers;

  // 1 if a writer currently holds the lock.
  int writer_active;

  // Number of writers waiting to acquire the lock.
  int waiting_writers;
};
#endif
