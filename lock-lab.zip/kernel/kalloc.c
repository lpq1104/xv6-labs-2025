// Physical memory allocator, for user processes,
// kernel stacks, page-table pages,
// and pipe buffers. Allocates whole 4096-byte pages.

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "riscv.h"
#include "defs.h"

void freerange(void *pa_start, void *pa_end);

extern char end[]; // first address after kernel.
                   // defined by kernel.ld.

struct run {
  struct run *next;
};

struct {
  struct spinlock lock;
  struct run *freelist;
} kmem[NCPU];

void
kinit()
{
  for(int i = 0; i < NCPU; i++){
    initlock(&kmem[i].lock, "kmem");
    kmem[i].freelist = 0;
  }
  freerange(end, (void*)PHYSTOP);
}

void
freerange(void *pa_start, void *pa_end)
{
  char *p;
  p = (char*)PGROUNDUP((uint64)pa_start);
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    kfree(p);
}

// Free the page of physical memory pointed at by pa,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);

  r = (struct run*)pa;

  push_off();
  int id = cpuid();

  acquire(&kmem[id].lock);
  r->next = kmem[id].freelist;
  kmem[id].freelist = r;
  release(&kmem[id].lock);

  pop_off();
}

// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
  struct run *r = 0;

  push_off();
  int id = cpuid();

  // 优先从当前 CPU 的空闲链表分配。
  acquire(&kmem[id].lock);
  r = kmem[id].freelist;
  if(r != 0)
    kmem[id].freelist = r->next;
  release(&kmem[id].lock);

  /*
   * 当前 CPU 没有空闲页时，从其他 CPU 偷取。
   * 每次最多拿 STEAL_BATCH 页，避免长时间持有 donor 的锁。
   */
  if(r == 0){
    for(int offset = 1; offset < NCPU; offset++){
      int donor = (id + offset) % NCPU;

      acquire(&kmem[donor].lock);

      r = kmem[donor].freelist;
      if(r != 0)
        kmem[donor].freelist = r->next;

      release(&kmem[donor].lock);

      if(r != 0)
        break;
    }
  }

  pop_off();

  if(r != 0)
    memset((char*)r, 5, PGSIZE);

  return (void*)r;
}
