// Physical memory allocator, for user processes,
// kernel stacks, page-table pages,
// and pipe buffers. Allocates whole 4096-byte pages.

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "riscv.h"
#include "defs.h"

void freerange(void *pa_start, void *pa_end);

extern char end[]; // first address after kernel.
                   // defined by kernel.ld.

struct run {
  struct run *next;
};

#define NPAGE ((PHYSTOP - KERNBASE) / PGSIZE)
#define PA2IDX(pa) (((uint64)(pa) - KERNBASE) / PGSIZE)

struct {
  struct spinlock lock;
  struct run *freelist;
  int refcnt[NPAGE];
} kmem;

void
kinit()
{
  initlock(&kmem.lock, "kmem");
  freerange(end, (void*)PHYSTOP);
}

void
freerange(void *pa_start, void *pa_end)
{
  char *p;

  p = (char *)PGROUNDUP((uint64)pa_start);
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE) {
    // kfree() decrements the count, so initialize it to one.
    kmem.refcnt[PA2IDX(p)] = 1;
    kfree(p);
  }
}

// Free the page of physical memory pointed at by pa,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
  struct run *r;
  int index;

  if (((uint64)pa % PGSIZE) != 0 ||
      (char *)pa < end ||
      (uint64)pa >= PHYSTOP)
    panic("kfree");

  index = PA2IDX(pa);

  acquire(&kmem.lock);

  if (kmem.refcnt[index] < 1)
    panic("kfree ref");

  kmem.refcnt[index]--;

  // Other page tables still reference this page.
  if (kmem.refcnt[index] > 0) {
    release(&kmem.lock);
    return;
  }

  // No references remain; return the page to the free list.
  memset(pa, 1, PGSIZE);

  r = (struct run *)pa;
  r->next = kmem.freelist;
  kmem.freelist = r;

  release(&kmem.lock);
}

// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
  struct run *r;

  acquire(&kmem.lock);

  r = kmem.freelist;
  if (r) {
    kmem.freelist = r->next;
    kmem.refcnt[PA2IDX(r)] = 1;
  }

  release(&kmem.lock);

  if (r)
    memset((char *)r, 5, PGSIZE);

  return (void *)r;
}


void
krefinc(void *pa)
{
  int index;

  if (((uint64)pa % PGSIZE) != 0 ||
      (char *)pa < end ||
      (uint64)pa >= PHYSTOP)
    panic("krefinc");

  index = PA2IDX(pa);

  acquire(&kmem.lock);

  if (kmem.refcnt[index] < 1)
    panic("krefinc ref");

  kmem.refcnt[index]++;

  release(&kmem.lock);
}
