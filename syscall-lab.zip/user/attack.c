#include "kernel/types.h"
#include "kernel/fcntl.h"
#include "user/user.h"
#include "kernel/riscv.h"
#define DATASIZE (8*4096)  //heap的大小为8页，共32k，一页4kB

int
main(int argc, char *argv[])
{
  // Your code here.
  //分配heap
  char* buf = sbrk(DATASIZE);  //堆的大小为8页
  char ch[DATASIZE/4];  //字符串大小为8k
  int j = 0;//

  for(int i = 0; i < DATASIZE; i++){
    char c = buf[i];
    if(c == '\0' && (j >= 2 && j < DATASIZE/4)){
      //遇到/0,并且j大于2且在合法范围内则代表可能找到了想要的东西，截断字符串
      ch[j++] = '\0';
      //打印
      printf("%s",ch);
      printf("\n");
      //j置为0继续找剩余符合条件的字符串（假设还没有扫码到heap的尽头的情况下）
      j = 0;
    }
    //符合字符条件并且j的范围合理
    if( ((c >='a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) && j < DATASIZE/4 - 1){
      //符合条件则赋值给字符串数组
      ch[j++] = c;
    }
    else{
      //不连续或者不是字符则将j值为0
      j=0;
    }
  }
  exit(1);
}
