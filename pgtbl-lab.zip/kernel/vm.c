#include "param.h"
#include "types.h"
#include "memlayout.h"
#include "elf.h"
#include "riscv.h"
#include "defs.h"
#include "spinlock.h"
#include "proc.h"
#include "fs.h"

/*
 * the kernel's page table.
 */
pagetable_t kernel_pagetable;

extern char etext[];  // kernel.ld sets this to end of kernel code.

extern char trampoline[]; // trampoline.S

// Make a direct-map page table for the kernel.
pagetable_t
kvmmake(void)
{
  pagetable_t kpgtbl;

  kpgtbl = (pagetable_t) kalloc();
  memset(kpgtbl, 0, PGSIZE);

  // uart registers
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);

  // virtio mmio disk interface
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);

#ifdef LAB_NET
  // PCI-E ECAM (configuration space), for pci.c
  kvmmap(kpgtbl, 0x30000000L, 0x30000000L, 0x10000000, PTE_R | PTE_W);

  // pci.c maps the e1000's registers here.
  kvmmap(kpgtbl, 0x40000000L, 0x40000000L, 0x20000, PTE_R | PTE_W);
#endif  

  // PLIC
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);

  // map kernel text executable and read-only.
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);

  // map kernel data and the physical RAM we'll make use of.
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);

  // map the trampoline for trap entry/exit to
  // the highest virtual address in the kernel.
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);

  // allocate and map a kernel stack for each process.
  proc_mapstacks(kpgtbl);
  
  return kpgtbl;
}

// Initialize the kernel_pagetable, shared by all CPUs.
void
kvminit(void)
{
  kernel_pagetable = kvmmake();
}

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));

  // flush stale entries from the TLB.
  sfence_vma();
}

// Return the address of the PTE in page table pagetable
// that corresponds to virtual address va.  If alloc!=0,
// create any required page-table pages.
//
// The risc-v Sv39 scheme has three levels of page-table
// pages. A page-table page contains 512 64-bit PTEs.
// A 64-bit virtual address is split into five fields:
//   39..63 -- must be zero.
//   30..38 -- 9 bits of level-2 index.
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
// Walk the page-table tree and report the level at which
// the returned PTE was found.
//
// A leaf may occur at level 1 for a 2-MiB superpage.
static pte_t *
walklevel(pagetable_t pagetable, uint64 va, int alloc,
          int *levelout)
{
  if(va >= MAXVA)
    panic("walk");

  for(int level = 2; level > 0; level--){
    pte_t *pte = &pagetable[PX(level, va)];

    if(*pte & PTE_V){
      // A valid PTE with R, W, or X is already a leaf.
      if(*pte & (PTE_R | PTE_W | PTE_X)){
        if(levelout)
          *levelout = level;
        return pte;
      }

      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc ||
         (pagetable = (pde_t*)kalloc()) == 0)
        return 0;

      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }

  if(levelout)
    *levelout = 0;

  return &pagetable[PX(0, va)];
}

pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
  return walklevel(pagetable, va, alloc, 0);
}

// Return the level-1 PTE corresponding to va.
// Allocate the required level-1 page-table page when alloc != 0.
static pte_t *
walksuper(pagetable_t pagetable, uint64 va, int alloc)
{
  if(va >= MAXVA)
    panic("walksuper");

  pte_t *pte2 = &pagetable[PX(2, va)];
  pagetable_t level1;

  if(*pte2 & PTE_V){
    // A level-2 leaf would be a 1-GiB page, which xv6
    // does not create here.
    if(*pte2 & (PTE_R | PTE_W | PTE_X))
      return 0;

    level1 = (pagetable_t)PTE2PA(*pte2);
  } else {
    if(!alloc || (level1 = (pagetable_t)kalloc()) == 0)
      return 0;

    memset(level1, 0, PGSIZE);
    *pte2 = PA2PTE(level1) | PTE_V;
  }

  return &level1[PX(1, va)];
}

// Look up a virtual address, return the physical address,
// or 0 if not mapped.
// Can only be used to look up user pages.
uint64
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;
  int level;

  if(va >= MAXVA)
    return 0;

  pte = walklevel(pagetable, va, 0, &level);
  if(pte == 0)
    return 0;
  if((*pte & PTE_V) == 0)
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  if(level == 1)
    pa += PGROUNDDOWN(va) & (SUPERPGSIZE - 1);
  return pa;
}

static void
vmprintwalk(pagetable_t pagetable, int level, uint64 va)
{
  for(int i = 0; i < 512; i++){
    pte_t pte = pagetable[i];

    if((pte & PTE_V) == 0)
      continue;

    uint64 pteva =
      va | ((uint64)i << PXSHIFT(level));

    // level 2: one " .."
    // level 1: two " .."
    // level 0: three " .."
    for(int depth = 0;
        depth < 3 - level;
        depth++)
      printf(" ..");

    printf("%p: pte %p pa %p\n",
       (void*)pteva,
       (void*)pte,
       (void*)PTE2PA(pte));

    if(level > 0 &&
       (pte & (PTE_R | PTE_W | PTE_X)) == 0){
      vmprintwalk(
        (pagetable_t)PTE2PA(pte),
        level - 1,
        pteva
      );
    }
  }
}

void
vmprint(pagetable_t pagetable)
{
  printf("page table %p\n", (void*)pagetable);
  vmprintwalk(pagetable, 2, 0);
}


// add a mapping to the kernel page table.
// only used when booting.
void
kvmmap(pagetable_t kpgtbl, uint64 va, uint64 pa, uint64 sz, int perm)
{
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    panic("kvmmap");
}

// Create PTEs for virtual addresses starting at va that refer to
// physical addresses starting at pa.
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    panic("mappages: size not aligned");

  if(size == 0)
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
      return -1;
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    pa += PGSIZE;
  }
  return 0;
}

// Map one 2-MiB physical superpage at a 2-MiB-aligned
// user virtual address.
static int
mapsuperpage(pagetable_t pagetable, uint64 va,
             uint64 pa, int perm)
{
  pte_t *pte;

  if((va % SUPERPGSIZE) != 0)
    panic("mapsuperpage: va not aligned");
  if((pa % SUPERPGSIZE) != 0)
    panic("mapsuperpage: pa not aligned");

  pte = walksuper(pagetable, va, 1);
  if(pte == 0)
    return -1;

  if(*pte & PTE_V){
    // If R/W/X is set, this is an existing leaf mapping
    // and really is a remap error.
    if(*pte & (PTE_R | PTE_W | PTE_X))
      panic("mapsuperpage: leaf remap");

    // Otherwise the level-1 PTE points to a level-0
    // page table. It may be an empty page table left
    // behind after ordinary mappings were removed.
    pagetable_t level0 =
      (pagetable_t)PTE2PA(*pte);

    // It is safe to replace the level-0 page table only
    // when all of its PTEs are invalid.
    for(int i = 0; i < 512; i++){
      if(level0[i] & PTE_V)
        return -1;
    }

    // Reclaim the empty level-0 page-table page.
    kfree((void*)level0);
    *pte = 0;
  }

  // Install a level-1 leaf mapping.
  *pte = PA2PTE(pa) | perm | PTE_R | PTE_V;

  sfence_vma();
  return 0;
}

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
  if(pagetable == 0)
    return 0;
  memset(pagetable, 0, PGSIZE);
  return pagetable;
}

// Convert one level-1 2-MiB leaf into 512 level-0
// 4-KiB mappings without copying the page contents.
// Demote a superpage when sbrk() removes the tail of it.
//
// Pages in [superva, va) must remain mapped.
// Pages in [va, superva + SUPERPGSIZE) are removed.
static int
demotesuperpage(pagetable_t pagetable, uint64 va)
{
  pte_t *superpte;
  pagetable_t level0;
  uint64 superva;
  uint64 superpa;
  uint flags;
  uint64 keep_pages;
  int level;

  if((va % PGSIZE) != 0)
    panic("demotesuperpage: va not aligned");

  superpte = walklevel(pagetable, va, 0, &level);
  if(superpte == 0 ||
     (*superpte & PTE_V) == 0 ||
     level != 1)
    return -1;

  superva = SUPERPGROUNDDOWN(va);
  superpa = PTE2PA(*superpte);
  flags = PTE_FLAGS(*superpte);

  keep_pages = (va - superva) / PGSIZE;

  // This case should normally have been handled as a
  // complete superpage removal by uvmunmap().
  if(keep_pages == 0)
    return -1;

  level0 = (pagetable_t)kalloc();
  if(level0 == 0)
    return -1;

  memset(level0, 0, PGSIZE);

  // Copy only the prefix that remains part of the
  // process after sbrk() shrinks it.
  for(uint64 i = 0; i < keep_pages; i++){
    char *mem = kalloc();

    if(mem == 0){
      // The old superpage PTE has not been changed yet,
      // so it is safe to release partial work.
      for(uint64 j = 0; j < i; j++)
        kfree((void*)PTE2PA(level0[j]));

      kfree((void*)level0);
      return -1;
    }

    memmove(mem,
            (void*)(superpa + i * PGSIZE),
            PGSIZE);

    level0[i] = PA2PTE(mem) | flags;
  }

  // Replace the level-1 leaf with a pointer to the
  // newly created level-0 page table.
  *superpte = PA2PTE(level0) | PTE_V;

  sfence_vma();

  // The remaining data now lives in ordinary pages,
  // so the original 2-MiB block can be reused.
  superfree((void*)superpa);

  return 0;
}

// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va,
         uint64 npages, int do_free)
{
  uint64 a;
  uint64 end;

  if((va % PGSIZE) != 0)
    panic("uvmunmap: not aligned");

  end = va + npages * PGSIZE;
  a = va;

  while(a < end){
    pte_t *pte;
    int level;

    pte = walklevel(pagetable, a, 0, &level);

    if(pte == 0 || (*pte & PTE_V) == 0){
      a += PGSIZE;
      continue;
    }

    if(level == 1){
      uint64 superva = SUPERPGROUNDDOWN(a);

      // The requested range contains this complete
      // 2-MiB superpage.
      if(a == superva && end - a >= SUPERPGSIZE){
        if(do_free)
          superfree((void*)PTE2PA(*pte));

        *pte = 0;
        a += SUPERPGSIZE;
        continue;
      }

      // Only part of the superpage is being unmapped.
      if(demotesuperpage(pagetable, a) < 0)
        panic("uvmunmap: demote");

      // Do not advance a. The next iteration will find
      // the newly created level-0 ordinary-page PTE.
      continue;
    }

    if(level != 0)
      panic("uvmunmap: unsupported leaf");

    if((*pte & (PTE_R | PTE_W | PTE_X)) == 0)
      panic("uvmunmap: not a leaf");

    if(do_free)
      kfree((void*)PTE2PA(*pte));

    *pte = 0;
    a += PGSIZE;
  }
}

// Allocate PTEs and physical memory to grow process from oldsz to
// newsz, which need not be page aligned.  Returns new size or 0 on error.4
uint64
uvmalloc(pagetable_t pagetable, uint64 oldsz,
         uint64 newsz, int xperm)
{
  char *mem;
  uint64 a;
  uint64 start;

  if(newsz < oldsz)
    return oldsz;

  start = PGROUNDUP(oldsz);

  for(a = start; a < newsz; ){
    // If the current virtual address is aligned and
    // at least 2 MiB remains, try a superpage.
    if((a % SUPERPGSIZE) == 0 &&
       newsz - a >= SUPERPGSIZE){

      mem = superalloc();

      if(mem !=0){
        memset(mem, 0, SUPERPGSIZE);

        if(mapsuperpage(pagetable, a,
                        (uint64)mem,
                        PTE_R | PTE_U | xperm) == 0){
          a += SUPERPGSIZE;
          continue;
        }

        // Mapping failed; return the physical block and
        // fall through to ordinary-page allocation.
        superfree(mem);
      }
    }

    mem = kalloc();
    if(mem == 0){
      uvmdealloc(pagetable, a, start);
      return 0;
    }

    memset(mem, 0, PGSIZE);

    if(mappages(pagetable, a, PGSIZE,
                (uint64)mem,
                PTE_R | PTE_U | xperm) != 0){
      kfree(mem);
      uvmdealloc(pagetable, a, start);
      return 0;
    }

    a += PGSIZE;
  }

  return newsz;
}

// Deallocate user pages to bring the process size from oldsz to
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
  if(newsz >= oldsz)
    return oldsz;

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      // backtrace();
      panic("freewalk: leaf");
    }
  }
  kfree((void*)pagetable);
}

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
  if(sz > 0)
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
}

// Given a parent process's page table, copy
// its memory into a child's page table.
// Copies both the page table and the
// physical memory.
// returns 0 on success, -1 on failure.
// frees any allocated pages on failure.
int
uvmcopy(pagetable_t old, pagetable_t new, uint64 sz)
{
  pte_t *pte;
  uint64 pa;
  uint64 i;
  uint flags;
  char *mem;
  int level;

  for(i = 0; i < sz; ){
    pte = walklevel(old, i, 0, &level);

    if(pte == 0 || (*pte & PTE_V) == 0){
      i += PGSIZE;
      continue;
    }

    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);

    if(level == 1){
      // A superpage mapping must start on a 2-MiB boundary.
      if((i % SUPERPGSIZE) != 0)
        panic("uvmcopy: unaligned superpage");

      mem = superalloc();
      if(mem == 0)
        goto err;

      memmove(mem, (char*)pa, SUPERPGSIZE);

      if(mapsuperpage(new, i, (uint64)mem, flags) != 0){
        superfree(mem);
        goto err;
      }

      i += SUPERPGSIZE;
      continue;
    }

    if(level != 0)
      panic("uvmcopy: unsupported leaf");

    mem = kalloc();
    if(mem == 0)
      goto err;

    memmove(mem, (char*)pa, PGSIZE);

    if(mappages(new, i, PGSIZE,
                (uint64)mem, flags) != 0){
      kfree(mem);
      goto err;
    }

    i += PGSIZE;
  }

  return 0;

err:
  uvmunmap(new, 0, PGROUNDUP(i) / PGSIZE, 1);
  return -1;
}

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
  if(pte == 0)
    panic("uvmclear");
  *pte &= ~PTE_U;
}

// Copy from kernel to user.
// Copy len bytes from src to virtual address dstva in a given page table.
// Return 0 on success, -1 on error.
int
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while(len > 0){
    va0 = PGROUNDDOWN(dstva);
    if (va0 >= MAXVA)
      return -1;

    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0) {
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
        return -1;
      }
    }

    if((pte = walk(pagetable, va0, 0)) == 0) {
      // printf("copyout: pte should exist %lx %ld\n", dstva, len);
      return -1;
    }


    // forbid copyout over read-only user text pages.
    if((*pte & PTE_W) == 0)
      return -1;
    
    n = PGSIZE - (dstva - va0);
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);

    len -= n;
    src += n;
    dstva = va0 + PGSIZE;
  }
  return 0;
}

// Copy from user to kernel.
// Copy len bytes to dst from virtual address srcva in a given page table.
// Return 0 on success, -1 on error.
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;
  
  while(len > 0){
    va0 = PGROUNDDOWN(srcva);
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0) {
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
        return -1;
      }
    }
    n = PGSIZE - (srcva - va0);
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);

    len -= n;
    dst += n;
    srcva = va0 + PGSIZE;
  }
  return 0;
}

// Copy a null-terminated string from user to kernel.
// Copy bytes to dst from virtual address srcva in a given page table,
// until a '\0', or max.
// Return 0 on success, -1 on error.
int
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    va0 = PGROUNDDOWN(srcva);
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    if(n > max)
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
        got_null = 1;
        break;
      } else {
        *dst = *p;
      }
      --n;
      --max;
      p++;
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    return 0;
  } else {
    return -1;
  }
}




// allocate and map user memory if process is referencing a page
// that was lazily allocated in sys_sbrk().
// returns 0 if va is invalid or already mapped, or if
// out of physical memory, and physical address if successful.
uint64
vmfault(pagetable_t pagetable, uint64 va, int read)
{
  uint64 mem;
  struct proc *p = myproc();
  

  if (va >= p->sz)
    return 0;
  va = PGROUNDDOWN(va);
  if(ismapped(pagetable, va)) {
    return 0;
  }
  mem = (uint64) kalloc();
  if(mem == 0)
    return 0;
  memset((void *) mem, 0, PGSIZE);
  if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W|PTE_U|PTE_R) != 0) {
    kfree((void *)mem);
    return 0;
  }
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va) {
  pte_t *pte = walk(pagetable, va, 0);
  if (pte == 0) {
    return 0;
  }
  if (*pte & PTE_V){
    return 1;
  }
  return 0;
}



#ifdef LAB_PGTBL
pte_t*
pgpte(pagetable_t pagetable, uint64 va) {
  return walk(pagetable, va, 0);
}
#endif
