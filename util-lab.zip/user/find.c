#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/fs.h"
#include "kernel/fcntl.h"
#include "kernel/param.h"
#include "user/user.h"

/*
 * 返回路径最后一部分的文件名。
 *
 * "./a/aa/b" -> "b"
 * "test"     -> "test"
 */
static char *
base_name(char *path)
{
  char *p;

  p = path + strlen(path);

  while(p > path && *(p - 1) != '/')
    p--;

  return p;
}

/*
 * 对匹配到的文件运行指定命令。
 *
 * 例如：
 *   cmd_argv = {"echo", "hi"}
 *   path = "./wc"
 *
 * 最终构造：
 *   {"echo", "hi", "./wc", 0}
 */
static void
run_command(char *path, char **cmd_argv, int cmd_argc)
{
  char *exec_argv[MAXARG];
  int i;
  int pid;

  /*
   * 还需要为文件路径和末尾的空指针预留两个位置。
   */
  if(cmd_argc + 2 > MAXARG){
    fprintf(2, "find: too many exec arguments\n");
    return;
  }

  /*
   * 复制 -exec 后面的命令参数。
   */
  for(i = 0; i < cmd_argc; i++)
    exec_argv[i] = cmd_argv[i];

  /*
   * 将匹配到的文件路径追加到命令参数末尾。
   */
  exec_argv[cmd_argc] = path;

  /*
   * exec 的参数数组必须以空指针结束。
   */
  exec_argv[cmd_argc + 1] = 0;

  pid = fork();

  if(pid < 0){
    fprintf(2, "find: fork failed\n");
    return;
  }

  if(pid == 0){
    /*
     * 子进程运行指定命令。
     *
     * exec_argv[0] 是程序名称，例如 "echo"。
     */
    exec(exec_argv[0], exec_argv);

    /*
     * exec 成功后不会返回。
     * 运行到这里说明 exec 失败。
     */
    fprintf(2, "find: exec %s failed\n", exec_argv[0]);
    exit(1);
  }

  /*
   * 父进程等待子进程结束，然后继续查找。
   */
  wait(0);
}

/*
 * 从 path 开始递归查找 target。
 *
 * cmd_argv == 0：
 *   基础 find 模式，匹配后打印路径。
 *
 * cmd_argv != 0：
 *   -exec 模式，匹配后运行命令。
 */
static void
find(char *path, char *target, char **cmd_argv, int cmd_argc)
{
  char buf[512];
  char name[DIRSIZ + 1];
  char *p;
  int fd;
  struct dirent de;
  struct stat st;

  fd = open(path, O_RDONLY);
  if(fd < 0){
    fprintf(2, "find: cannot open %s\n", path);
    return;
  }

  if(fstat(fd, &st) < 0){
    fprintf(2, "find: cannot stat %s\n", path);
    close(fd);
    return;
  }

  /*
   * 普通文件：比较路径最后的文件名。
   */
  if(st.type == T_FILE){
    if(strcmp(base_name(path), target) == 0){
      if(cmd_argv == 0)
        printf("%s\n", path);
      else
        run_command(path, cmd_argv, cmd_argc);
    }

    close(fd);
    return;
  }

  /*
   * 设备等其他类型不需要递归。
   */
  if(st.type != T_DIR){
    close(fd);
    return;
  }

  /*
   * 检查：
   * 父路径 + "/" + 最长文件名 + "\0"
   * 是否能放入 buf。
   */
  if(strlen(path) + 1 + DIRSIZ + 1 > sizeof(buf)){
    fprintf(2, "find: path too long\n");
    close(fd);
    return;
  }

  strcpy(buf, path);
  p = buf + strlen(buf);
  *p++ = '/';

  /*
   * 逐个读取目录项。
   */
  while(read(fd, &de, sizeof(de)) == sizeof(de)){
    if(de.inum == 0)
      continue;

    /*
     * de.name 不保证以 '\0' 结尾。
     */
    memmove(name, de.name, DIRSIZ);
    name[DIRSIZ] = '\0';

    /*
     * 防止无限递归。
     */
    if(strcmp(name, ".") == 0 || strcmp(name, "..") == 0)
      continue;

    /*
     * 拼接完整子路径。
     */
    memmove(p, name, strlen(name) + 1);

    /*
     * 将命令信息继续传给递归调用。
     */
    find(buf, target, cmd_argv, cmd_argc);
  }

  close(fd);
}

int
main(int argc, char *argv[])
{
  int cmd_argc;

  /*
   * 基础模式：
   * find path name
   */
  if(argc == 3){
    find(argv[1], argv[2], 0, 0);
    exit(0);
  }

  /*
   * -exec 模式至少需要：
   * find path name -exec command
   *
   * 一共至少 5 个参数。
   */
  if(argc < 5 || strcmp(argv[3], "-exec") != 0){
    fprintf(2,
            "usage: find path name [-exec command args...]\n");
    exit(1);
  }

  /*
   * argv[4] 开始是要执行的命令。
   */
  cmd_argc = argc - 4;

  /*
   * 命令参数 + 匹配文件路径 + 末尾空指针
   * 不能超过 MAXARG。
   */
  if(cmd_argc + 2 > MAXARG){
    fprintf(2, "find: too many exec arguments\n");
    exit(1);
  }

  find(argv[1], argv[2], &argv[4], cmd_argc);

  exit(0);
}
