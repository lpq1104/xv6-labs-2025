#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/fcntl.h"
#include "user/user.h"

static int
is_separator(char c)
{
  char *separators = " -\r\t\n./,";

  return strchr(separators, c) != 0;
}

static void
print_if_multiple(int number)
{
  if(number % 5 == 0 || number % 6 == 0)
    printf("%d\n", number);
}

static int
process_file(char *path)
{
  int fd;
  int n;
  char c;
  int number = 0;
  int in_number = 0;
  int can_start = 1;

  fd = open(path, O_RDONLY);
  if(fd < 0){
    fprintf(2, "sixfive: cannot open %s\n", path);
    return -1;
  }

  while((n = read(fd, &c, 1)) > 0){
    if(c >= '0' && c <= '9'){
      if(in_number){
        number = number * 10 + (c - '0');
      } else if(can_start){
        number = c - '0';
        in_number = 1;
      }

      can_start = 0;
    } else if(is_separator(c)){
      if(in_number)
        print_if_multiple(number);

      number = 0;
      in_number = 0;
      can_start = 1;
    } else {
      number = 0;
      in_number = 0;
      can_start = 0;
    }
  }

  if(n < 0){
    fprintf(2, "sixfive: read error in %s\n", path);
    close(fd);
    return -1;
  }

  /*
   * 文件结尾被题目视为隐式分隔符。
   * 因此，文件最后如果正好是一个数字，需要在这里处理。
   */
  if(in_number)
    print_if_multiple(number);

  close(fd);
  return 0;
}

int
main(int argc, char *argv[])
{
  int i;
  int failed = 0;

  if(argc < 2){
    fprintf(2, "usage: sixfive file...\n");
    exit(1);
  }

  for(i = 1; i < argc; i++){
    if(process_file(argv[i]) < 0)
      failed = 1;
  }

  exit(failed);
}
