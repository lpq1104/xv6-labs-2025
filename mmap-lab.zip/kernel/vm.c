#include "param.h"
#include "types.h"
#include "memlayout.h"
#include "elf.h"
#include "riscv.h"
#include "defs.h"
#include "spinlock.h"
#include "proc.h"
#include "fs.h"
#include "sleeplock.h"
#include "file.h"
#include "fcntl.h"

/*
 * the kernel's page table.
 */
pagetable_t kernel_pagetable;

extern char etext[];  // kernel.ld sets this to end of kernel code.

extern char trampoline[]; // trampoline.S

// Make a direct-map page table for the kernel.
pagetable_t
kvmmake(void)
{
  pagetable_t kpgtbl;

  kpgtbl = (pagetable_t) kalloc();
  memset(kpgtbl, 0, PGSIZE);

  // uart registers
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);

  // virtio mmio disk interface
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);

  // PLIC
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);

  // map kernel text executable and read-only.
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);

  // map kernel data and the physical RAM we'll make use of.
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);

  // map the trampoline for trap entry/exit to
  // the highest virtual address in the kernel.
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);

  // allocate and map a kernel stack for each process.
  proc_mapstacks(kpgtbl);
  
  return kpgtbl;
}

// add a mapping to the kernel page table.
// only used when booting.
// does not flush TLB or enable paging.
void
kvmmap(pagetable_t kpgtbl, uint64 va, uint64 pa, uint64 sz, int perm)
{
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    panic("kvmmap");
}

// Initialize the kernel_pagetable, shared by all CPUs.
void
kvminit(void)
{
  kernel_pagetable = kvmmake();
}

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));

  // flush stale entries from the TLB.
  sfence_vma();
}

// Return the address of the PTE in page table pagetable
// that corresponds to virtual address va.  If alloc!=0,
// create any required page-table pages.
//
// The risc-v Sv39 scheme has three levels of page-table
// pages. A page-table page contains 512 64-bit PTEs.
// A 64-bit virtual address is split into five fields:
//   39..63 -- must be zero.
//   30..38 -- 9 bits of level-2 index.
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
  if(va >= MAXVA)
    panic("walk");

  for(int level = 2; level > 0; level--) {
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
}

// Look up a virtual address, return the physical address,
// or 0 if not mapped.
// Can only be used to look up user pages.
uint64
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    return 0;

  pte = walk(pagetable, va, 0);
  if(pte == 0)
    return 0;
  if((*pte & PTE_V) == 0)
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}

// Create PTEs for virtual addresses starting at va that refer to
// physical addresses starting at pa.
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    panic("mappages: size not aligned");

  if(size == 0)
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
      return -1;
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    pa += PGSIZE;
  }
  return 0;
}

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
  if(pagetable == 0)
    return 0;
  memset(pagetable, 0, PGSIZE);
  return pagetable;
}

// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    if((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
      continue;   
    if((*pte & PTE_V) == 0)  // has physical page been allocated?
      continue;
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
  }
}

// Allocate PTEs and physical memory to grow a process from oldsz to
// newsz, which need not be page aligned.  Returns new size or 0 on error.
uint64
uvmalloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz, int xperm)
{
  char *mem;
  uint64 a;

  if(newsz < oldsz)
    return oldsz;

  oldsz = PGROUNDUP(oldsz);
  for(a = oldsz; a < newsz; a += PGSIZE){
    mem = kalloc();
    if(mem == 0){
      uvmdealloc(pagetable, a, oldsz);
      return 0;
    }
    memset(mem, 0, PGSIZE);
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
      kfree(mem);
      uvmdealloc(pagetable, a, oldsz);
      return 0;
    }
  }
  return newsz;
}

// Deallocate user pages to bring the process size from oldsz to
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
  if(newsz >= oldsz)
    return oldsz;

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    }
  }
  kfree((void*)pagetable);
}

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
  if(sz > 0)
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
}

// Given a parent process's page table, copy
// its memory into a child's page table.
// Copies both the page table and the
// physical memory.
// returns 0 on success, -1 on failure.
// frees any allocated pages on failure.
int
uvmcopy(pagetable_t old, pagetable_t new, uint64 sz)
{
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    if((pte = walk(old, i, 0)) == 0)
      continue;   // page table entry hasn't been allocated
    if((*pte & PTE_V) == 0)
      continue;   // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
      kfree(mem);
      goto err;
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
  return -1;
}

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
  if(pte == 0)
    panic("uvmclear");
  *pte &= ~PTE_U;
}

// Copy from kernel to user.
// Copy len bytes from src to virtual address dstva in a given page table.
// Return 0 on success, -1 on error.
int
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while(len > 0){
    va0 = PGROUNDDOWN(dstva);
    if(va0 >= MAXVA)
      return -1;
  
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0) {
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
        return -1;
      }
    }

    pte = walk(pagetable, va0, 0);
    // forbid copyout over read-only user text pages.
    if((*pte & PTE_W) == 0)
      return -1;
      
    n = PGSIZE - (dstva - va0);
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);

    len -= n;
    src += n;
    dstva = va0 + PGSIZE;
  }
  return 0;
}

// Copy from user to kernel.
// Copy len bytes to dst from virtual address srcva in a given page table.
// Return 0 on success, -1 on error.
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    va0 = PGROUNDDOWN(srcva);
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0) {
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
        return -1;
      }
    }
    n = PGSIZE - (srcva - va0);
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);

    len -= n;
    dst += n;
    srcva = va0 + PGSIZE;
  }
  return 0;
}

// Copy a null-terminated string from user to kernel.
// Copy bytes to dst from virtual address srcva in a given page table,
// until a '\0', or max.
// Return 0 on success, -1 on error.
int
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    va0 = PGROUNDDOWN(srcva);
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    if(n > max)
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
        got_null = 1;
        break;
      } else {
        *dst = *p;
      }
      --n;
      --max;
      p++;
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    return 0;
  } else {
    return -1;
  }
}

// allocate and map user memory if process is referencing a page
// that was lazily allocated in sys_sbrk().
// returns 0 if va is invalid or already mapped, or if
// out of physical memory, and physical address if successful.
uint64
vmfault(pagetable_t pagetable, uint64 va, int read)
{
  uint64 mem;
  struct proc *p = myproc();

  if (va >= p->sz)
    return 0;
  va = PGROUNDDOWN(va);
  if(ismapped(pagetable, va)) {
    return 0;
  }
  mem = (uint64) kalloc();
  if(mem == 0)
    return 0;
  memset((void *) mem, 0, PGSIZE);
  if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W|PTE_U|PTE_R) != 0) {
    kfree((void *)mem);
    return 0;
  }
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
  pte_t *pte = walk(pagetable, va, 0);
  if (pte == 0) {
    return 0;
  }
  if (*pte & PTE_V){
    return 1;
  }
  return 0;
}


// Handle a page fault in a file-backed mmap region.
//
// write is non-zero for a store page fault and zero for a load page fault.
// Return the newly allocated physical address on success.
// Return 0 if va is not in an mmap region, the access is not allowed,
// or the page cannot be allocated/read/mapped.
uint64
mmapfault(pagetable_t pagetable, uint64 va, int write)
{
  struct proc *p;
  struct vma *v;
  uint64 pageva;
  uint64 fileoff;
  uint64 remaining;
  uint64 mem;
  uint readlen;
  int perm;
  int nread;

  p = myproc();
  v = 0;

  // Find the VMA containing the faulting address.
  //
  // Use va rather than PGROUNDDOWN(va) for this check so that an
  // address past the requested mapping length is not accepted merely
  // because it is in the same final page.
  for(int i = 0; i < NVMA; i++){
    if(p->vmas[i].used &&
       va >= p->vmas[i].addr &&
       va < p->vmas[i].addr + p->vmas[i].length){
      v = &p->vmas[i];
      break;
    }
  }

  if(v == 0)
    return 0;

  // Reject accesses not allowed by the VMA.
  if(write){
    if((v->prot & PROT_WRITE) == 0)
      return 0;
  } else {
    if((v->prot & PROT_READ) == 0)
      return 0;
  }

  pageva = PGROUNDDOWN(va);

  // If it is already mapped, this fault was probably caused by a
  // permission violation rather than a missing page.
  if(ismapped(pagetable, pageva))
    return 0;

  // Calculate the offset of this page in the mapped file.
  fileoff = v->offset + (pageva - v->addr);

  // readi() accepts a 32-bit file offset in xv6.
  if((uint64)(uint)fileoff != fileoff)
    return 0;

  // Only read bytes that belong to this VMA. The rest of the physical
  // page remains zero-filled.
  remaining = v->length - (pageva - v->addr);

  if(remaining < PGSIZE)
    readlen = remaining;
  else
    readlen = PGSIZE;

  mem = (uint64)kalloc();
  if(mem == 0)
    return 0;

  // Important for short files and the final partial page.
  memset((void *)mem, 0, PGSIZE);

  // readi() requires the inode lock.
  ilock(v->file->ip);
  nread = readi(v->file->ip, 0, mem, (uint)fileoff, readlen);
  iunlock(v->file->ip);

  if(nread < 0){
    kfree((void *)mem);
    return 0;
  }

  // Convert mmap protection flags to RISC-V PTE flags.
  perm = PTE_U;

  if(v->prot & PROT_READ)
    perm |= PTE_R;

  if(v->prot & PROT_WRITE)
    perm |= PTE_W | PTE_R;

  // RISC-V does not support a writable-but-not-readable leaf PTE,
  // so a writable mmap page must also have PTE_R.
  if(mappages(pagetable, pageva, PGSIZE, mem, perm) != 0){
    kfree((void *)mem);
    return 0;
  }

  return mem;
}


// Write n bytes from a kernel physical address back to an inode.
//
// The write is split into transactions small enough for xv6's log,
// following the same idea as filewrite().
static int
vmawriteback(struct file *f, uint64 pa, uint fileoff, uint n)
{
  int max;
  uint written;
  uint n1;
  uint filesize;
  int result;

  // Determine the current file size. mmap writeback in this lab
  // must not extend the file past its existing end.
  ilock(f->ip);
  filesize = f->ip->size;
  iunlock(f->ip);

  // This mapped page begins completely past the end of the file.
  if(fileoff >= filesize)
    return 0;

  // The final mapped page may contain only part of the file.
  // Do not write the zero-filled remainder back and extend the file.
  if(n > filesize - fileoff)
    n = filesize - fileoff;

  max = ((MAXOPBLOCKS - 1 - 1 - 2) / 2) * BSIZE;
  written = 0;

  while(written < n){
    n1 = n - written;

    if(n1 > max)
      n1 = max;

    begin_op();

    ilock(f->ip);
    result = writei(f->ip, 0, pa + written,
                    fileoff + written, n1);
    iunlock(f->ip);

    end_op();

    if(result != n1)
      return -1;

    written += n1;
  }

  return 0;
}

// Unmap addr..addr+length from one mmap VMA.
//
// The lab guarantees that a partial unmap removes either the beginning
// or the end of a VMA, never a hole in its middle.
//
// Return 0 on success and -1 for an invalid range.
int
vmaunmap(struct proc *p, uint64 addr, uint64 length)
{
  struct vma *v;
  struct file *file;
  uint64 unmaplen;
  uint64 unmapend;
  uint64 vmapend;
  uint64 logicalend;
  uint64 a;
  uint64 pa;
  uint64 fileoff;
  uint n;
  pte_t *pte;
  int whole;
  int from_start;
  int from_end;
  int write_error;

  if(length == 0)
    return -1;

  // munmap addresses must be page-aligned.
  if(addr % PGSIZE)
    return -1;

  unmaplen = PGROUNDUP(length);

  // Detect rounding/addition overflow.
  if(unmaplen < length)
    return -1;

  if(addr + unmaplen < addr)
    return -1;

  unmapend = addr + unmaplen;
  v = 0;

  // Find a VMA whose page-rounded range contains the entire request.
  for(int i = 0; i < NVMA; i++){
    if(p->vmas[i].used == 0)
      continue;

    vmapend = p->vmas[i].addr + PGROUNDUP(p->vmas[i].length);

    if(addr >= p->vmas[i].addr &&
       addr < vmapend &&
       unmapend <= vmapend){
      v = &p->vmas[i];
      break;
    }
  }

  // Linux-style munmap of an already-unmapped range succeeds.
  // mmaptest contains a test for this behavior.
  if(v == 0)
    return 0;

  vmapend = v->addr + PGROUNDUP(v->length);

  whole = (addr == v->addr && unmapend == vmapend);
  from_start = (addr == v->addr);
  from_end = (unmapend == vmapend);

  // The lab guarantees that user programs do not punch a hole in
  // the middle, but reject it defensively.
  if(!whole && !from_start && !from_end)
    return -1;

  logicalend = v->addr + v->length;
  write_error = 0;

  // Process every page in the requested range. Some pages may never
  // have faulted in; those pages have no valid PTE and are skipped.
  for(a = addr; a < unmapend; a += PGSIZE){
    pte = walk(p->pagetable, a, 0);

    if(pte == 0)
      continue;

    if((*pte & PTE_V) == 0)
      continue;

    pa = PTE2PA(*pte);

    // The lab permits writing all loaded shared pages without
    // checking the PTE dirty bit. A read-only mapping cannot have
    // been modified, so only writable MAP_SHARED VMAs are written.
    if(v->flags == MAP_SHARED  && a < logicalend){

      n = PGSIZE;

      // Do not write past the logical end of a partial final page.
      if(a + PGSIZE > logicalend)
        n = logicalend - a;

      fileoff = v->offset + (a - v->addr);

      if((uint64)(uint)fileoff != fileoff){
        write_error = 1;
      } else if(vmawriteback(v->file, pa,
                            (uint)fileoff, n) < 0){
        write_error = 1;
      }
    }

    // We already verified that this page is mapped, so this also
    // works with xv6 versions whose uvmunmap() dislikes missing PTEs.
    uvmunmap(p->pagetable, a, 1, 1);
  }

  if(whole){
    // Save the file pointer before clearing the VMA.
    file = v->file;

    v->used = 0;
    v->addr = 0;
    v->length = 0;
    v->prot = 0;
    v->flags = 0;
    v->file = 0;
    v->offset = 0;

    // Drop the reference acquired by filedup() in sys_mmap().
    fileclose(file);
  } else if(from_start){
    // Remove pages from the beginning.
    v->addr += unmaplen;
    v->offset += unmaplen;
    v->length -= unmaplen;
  } else {
    // Remove pages from the end.
    v->length = addr - v->addr;
  }

  // Recompute the next mmap address. This safely reuses free space

  if(write_error)
    return -1;

  return 0;
}
